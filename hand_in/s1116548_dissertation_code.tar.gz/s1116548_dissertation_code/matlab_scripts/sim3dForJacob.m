%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% sim3dForJacob.m
%%
%% Brian Hamilton 2017
%% 
%% This script implements the 3D acoustic wave equation over three non-trivial
%% domains.
%% 
%% Parameters include the grid spacing, speed of sound, duration, and reflection
%% coefficient to apply to walls.
%% 
%% The simulation can use a vectorised FDTD update or a SPMV-based FDTD update.
%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;

%% PARAMETERS

%grid spacing (m)
h=0.1;
%speed of sound (m/s)
c=343;
%duration of simulation (s)
duration=0.1;
%reflection coefficient (between zero and one);
R=0.9;

%some flags
draw=1;
simulate=1;
usematrix=1;

%%three choices for room types (uncomment one)
%roomtype='rotatedbox';
%roomtype='Lroom';
roomtype='hexdome';


%% SETUP

rotationmatrix = @(theta_x,theta_y,theta_z) ...
   [1 0 0;0 cos(theta_x) -sin(theta_x);0 sin(theta_x) cos(theta_x)]*...
   [cos(theta_y) 0 sin(theta_y);0 1 0;-sin(theta_y) 0 cos(theta_y)]*...
   [cos(theta_z) -sin(theta_z) 0;sin(theta_z) cos(theta_z) 0;0 0 1];

switch roomtype
   case 'rotatedbox'
      [x0,y0,z0]=deal(0,0,0);
      [dx,dy,dz]=deal(sqrt(5)*4,sqrt(3)*4,4);
      [theta_x,theta_y,theta_z]=deal(0,pi/6,pi/4);
      Sxyz=[0 0 0];
      Rxyz=[1 1 1];

      nodes = [...
         x0 y0 z0; ...
         x0+dx y0 z0; ...
         x0 y0+dy z0; ...
         x0+dx y0+dy z0; ...
         x0 y0 z0+dz; ...
         x0+dx y0 z0+dz; ...
         x0 y0+dy z0+dz; ...
         x0+dx y0+dy z0+dz];

      %center box about origin
      nodes=bsxfun(@minus,nodes,mean(nodes,1));
      A=[1 0 0;0 1 0;0 0 1];b=0.5*(max(nodes,[],1)-min(nodes,[],1));

      Rm=rotationmatrix(theta_x,theta_y,theta_z);

      nodesR=zeros(size(nodes));
      for i=1:size(nodes,1)
         nodesR(i,:)=nodes(i,:)*Rm';
      end

      Ar=zeros(size(A));
      for i=1:size(A,1)
         Ar(i,:)=A(i,:)*Rm';
      end
      infun= @(X,Y,Z) all(bsxfun(@le,abs([X(:),Y(:),Z(:)]*Ar'),b),2);
      allnodes=nodesR;

      if draw==1
         faces = [1 3 4 2;5 6 8 7;2 4 8 6;1 5 7 3;1 2 6 5;3 7 8 4];
         %draw boxes
         figure
         if simulate==1
            gca1=subplot(4,1,1:3);
         end
         patch('faces',faces,'vertices',nodesR,'facecolor','none','linestyle',':')
         hold all;
         plot3(Sxyz(1),Sxyz(2),Sxyz(3),'x','markersize',10,'linewidth',2);
         plot3(Rxyz(1),Rxyz(2),Rxyz(3),'o','markersize',10,'linewidth',2);
         xlabel('x')
         ylabel('y')
         view(3);axis equal;grid on
      end

   case 'Lroom'
      Sxyz=[8 9 1];
      Rxyz=[8 4 1];

      [x0,y0,z0]=deal(0,0,0);
      [dx,dy,dz]=deal(10,10,2);
      nodes1 = [...
         x0 y0 z0; ...
         x0+dx y0 z0; ...
         x0 y0+dy z0; ...
         x0+dx y0+dy z0; ...
         x0 y0 z0+dz; ...
         x0+dx y0 z0+dz; ...
         x0 y0+dy z0+dz; ...
         x0+dx y0+dy z0+dz];

      ax=0.6;ay=0.5; %less than one, but make sure Rx,Sx inside;
      nodes2 = [...
         x0 y0 z0; ...
         x0+dx*ax y0 z0; ...
         x0 y0+dy*ay z0; ...
         x0+dx*ax y0+dy*ay z0; ...
         x0 y0 z0+dz; ...
         x0+dx*ax y0 z0+dz; ...
         x0 y0+dy*ay z0+dz; ...
         x0+dx*ax y0+dy*ay z0+dz];


      A1=[1 0 0;0 1 0;0 0 1];b1=[max(nodes1,[],1),-min(nodes1,[],1)];
      A1=[A1;-A1];

      A2=[1 0 0;0 1 0;0 0 1];b2=[max(nodes2,[],1),-min(nodes2,[],1)];
      A2=[A2;-A2];

      infun = @(X,Y,Z) all(bsxfun(@le,[X(:),Y(:),Z(:)]*A1',b1),2) & ~all(bsxfun(@le,[X(:),Y(:),Z(:)]*A2',b2),2);

      allnodes=[nodes1;nodes2];

      if draw==1
         faces = [1 3 4 2;5 6 8 7;2 4 8 6;1 5 7 3;1 2 6 5;3 7 8 4];
         figure
         if simulate==1
            gca1=subplot(4,1,1:3);
         end
         patch('faces',faces,'vertices',nodes1,'facecolor','none','linestyle',':')
         hold on;
         patch('faces',faces,'vertices',nodes2,'facecolor','none','linestyle',':')
         view(3);axis equal;grid on
         plot3(Sxyz(1),Sxyz(2),Sxyz(3),'x','markersize',10,'linewidth',2);
         plot3(Rxyz(1),Rxyz(2),Rxyz(3),'o','markersize',10,'linewidth',2);
         xlabel('x')
         ylabel('y')
      end

   case 'hexdome'
      Sxyz=[0 -4 1];
      Rxyz=[3 2 1];
      [x0,y0,z0]=deal(0,0,0);
      [dx,dy,dz]=deal(2.5,12,2);
      Rsphere=dz;
      nodes1 = [...
         x0 y0 z0; ...
         x0+dx y0 z0; ...
         x0 y0+dy z0; ...
         x0+dx y0+dy z0; ...
         x0 y0 z0+dz; ...
         x0+dx y0 z0+dz; ...
         x0 y0+dy z0+dz; ...
         x0+dx y0+dy z0+dz];

      %center box about origin in x-y
      nodes1(:,[1 2])=bsxfun(@minus,nodes1(:,[1 2]),mean(nodes1(:,[1 2]),1));
      A1=[1 0 0;0 1 0;0 0 1];
      A1=[A1;-A1];
      b=[max(nodes1,[],1),-min(nodes1,[],1)];

      nodes2=zeros(size(nodes1));

      Rm=rotationmatrix(0,0,pi/3);
      for i=1:size(nodes1,1)
         nodes2(i,:)=nodes1(i,:)*Rm';
      end
      A2=zeros(size(A1));
      for i=1:size(A1,1)
         A2(i,:)=A1(i,:)*Rm';
      end

      nodes3=zeros(size(nodes1));
      Rm=rotationmatrix(0,0,-pi/3);
      for i=1:size(nodes1,1)
         nodes3(i,:)=nodes1(i,:)*Rm';
      end
      A3=zeros(size(A1));
      for i=1:size(A1,1)
         A3(i,:)=A1(i,:)*Rm';
      end

      infun = @(X,Y,Z) all(bsxfun(@le,[X(:),Y(:),Z(:)]*A1',b),2) | all(bsxfun(@le,[X(:),Y(:),Z(:)]*A2',b),2) | all(bsxfun(@le,[X(:),Y(:),Z(:)]*A3',b),2) | (X(:).^2 + Y(:).^2 + (Z(:)-dz).^2)<=Rsphere^2;

      allnodes=[nodes1;nodes2;nodes3;[0 0 Rsphere+dz]];

      if draw==1
         [Xs,Ys,Zs]=sphere(20);

         Xs=Xs*Rsphere;
         Ys=Ys*Rsphere;
         Zs=Zs*Rsphere;
         Zs=Zs+dz;
         faces = [1 3 4 2;5 6 8 7;2 4 8 6;1 5 7 3;1 2 6 5;3 7 8 4];
         figure
         if simulate==1
            gca1=subplot(4,1,1:3);
         end
         patch('faces',faces,'vertices',nodes1,'facecolor','none','linestyle',':')
         hold on;
         patch('faces',faces,'vertices',nodes2,'facecolor','none','linestyle',':')
         patch('faces',faces,'vertices',nodes3,'facecolor','none','linestyle',':')
         surf(Xs,Ys,Zs,'facecolor','none','linestyle',':');
         view(3);axis equal;grid on
         plot3(Sxyz(1),Sxyz(2),Sxyz(3),'x','markersize',10,'linewidth',2);
         plot3(Rxyz(1),Rxyz(2),Rxyz(3),'o','markersize',10,'linewidth',2);
         xlabel('x')
         ylabel('y')

      end
end

%% CHECK INSIDE

%get bounding box size
xyzmin=min(allnodes,[],1);
xyzmax=max(allnodes,[],1);
Lxyz=xyzmax-xyzmin;

%set up grid to check in/out
xv=xyzmin(1)-h:h:xyzmax(1)+h;
yv=xyzmin(2)-h:h:xyzmax(2)+h;
zv=xyzmin(3)-h:h:xyzmax(3)+h;
[X,Y,Z]=meshgrid(xv,yv,zv);

%check if inside (returns booleans)
IN=infun(X,Y,Z);

%to see the points
if draw==1 && simulate==0
   plot3(X(IN),Y(IN),Z(IN),'.');
   title('points inside');
end

evol=sum(IN)*h^3;
fprintf('estimated interior volume: %.2f, ratio of bounding box %.2f\n',evol,evol/prod(Lxyz))

%set up rest of finite difference scheme
Ni=size(X,1);
Nj=size(X,2);
Nk=size(X,3);

%calculate adjacencies
nb=[1,-1,Ni,-Ni,Ni*Nj,-Ni*Nj];
ADJ=false(Ni*Nj*Nk,6);
iIN=find(IN); %returns linear indices
ADJ(IN,:)=IN(bsxfun(@plus,iIN,nb));


if usematrix==1
   %create Laplacian matrix
   Nii=Ni*Nj*Nk;
   iV=repmat(iIN,1,6);
   jV=bsxfun(@plus,iIN,nb);
   vV=ADJ(IN(:),:);
   AM=sparse(iV(:),jV(:),vV(:),Nii,Nii);
   L=AM-spdiags(sum(AM,2),0,speye(Nii));
   if draw==1 && simulate==0
      figure;spy(L)
      title('Laplacian matrix');
   end
else
   %number of neighbours for interior points
   Ki=zeros(Ni,Nj,Nk); 
   Ki(IN(:))=sum(ADJ(IN(:),:),2);
end

if simulate==0
   return;
end

%% RUN SIMULATION

%courant number squared
l2=0.33;
%courant number 
l=sqrt(l2);
%time-step 
Ts=h*l/c;
fprintf('sample rate=%.1f Hz\n',1/Ts)

uzz=zeros(Ni,Nj,Nk);
uz=zeros(Ni,Nj,Nk);
udraw=zeros(Ni,Nj,Nk);

inijk=(round((Sxyz-xyzmin+h)/h)-[1 0 1])*[Ni;1;Ni*Nj];
outijk=(round((Rxyz-xyzmin+h)/h)-[1 0 1])*[Ni;1;Ni*Nj];

N=ceil(duration/Ts);
uout=nan(N,1);
usource=zeros(N,1);

%source, raised cosine 
Tn=floor(10/l);
usource(1:Tn)=hann(Tn);

%wall admittance
g=(1-R)/(1+R);

if usematrix==1
   I=spdiags(IN(:),0,speye(Nii));
   Qv=6-sum(AM,2);
   M1=spdiags(1./(1+0.5*l*g*Qv),0,speye(Nii))*(2*I+l2*L);
   M2=spdiags(1./(1+0.5*l*g*Qv),0,speye(Nii))*(0.5*l*g*spdiags(Qv,0,speye(Nii))-I);
end

Ts2c2h3=Ts*Ts*c*c/h/h/h;

for n=1:N
   if usematrix==1
      uzz(:)=M2*uzz(:)+M1*uz(:);
   else
      uzz(IN)=((2-l2*Ki(IN)).*uz(IN) + l2*(uz(iIN+1) + uz(iIN-1) + uz(iIN+Ni) + uz(iIN-Ni) + uz(iIN+Ni*Nj) + uz(iIN-Ni*Nj))+(0.5*l*g*(6-Ki(IN))-1).*uzz(IN))./(1+0.5*l*g*(6-Ki(IN)));
   end

   %input
   uzz(inijk)=uzz(inijk)+Ts2c2h3*usource(n);

   %output
   uout(n)=uz(outijk);

   %swap pointers
   [uzz,uz]=deal(uz,uzz);   

   if draw==1
      if n==1
         Nif=round((Sxyz(2)-xyzmin(2))/h)+1;
         Njf=round((Sxyz(1)-xyzmin(1))/h)+1;
         Nkf=round((Sxyz(3)-xyzmin(3))/h)+1;

         %subplot(4,1,1:3)
         h2=surf(squeeze(X(Nif,:,:)),squeeze(Y(Nif,:,:)),squeeze(Z(Nif,:,:)),squeeze(uzz(Nif,:,:)));
         hold on;
         h3=surf(squeeze(X(:,Njf,:)),squeeze(Y(:,Njf,:)),squeeze(Z(:,Njf,:)),squeeze(uzz(:,Njf,:)));
         h4=surf(squeeze(X(:,:,Nkf)),squeeze(Y(:,:,Nkf)),squeeze(Z(:,:,Nkf)),squeeze(uzz(:,:,Nkf)));
         ffa=0.8;
         alphamask=zeros(Ni,Nj,Nk);
         alphamask(IN)=ffa;
         set(h2, 'FaceColor','texturemap','EdgeColor','none','alphadata',squeeze(alphamask(Nif,:,:)),'alphadatamapping','none','facealpha','texturemap');
         set(h3, 'FaceColor','texturemap','EdgeColor','none','alphadata',squeeze(alphamask(:,Njf,:)),'alphadatamapping','none','facealpha','texturemap');
         set(h4, 'FaceColor','texturemap','EdgeColor','none','alphadata',squeeze(alphamask(:,:,Nkf)),'alphadatamapping','none','facealpha','texturemap');
         colormap(jet);

         grid on;axis equal;
         xlabel('x');
         ylabel('y');
         ca=colorbar;
         ylabel(ca,'uout');

         gca2=subplot(4,1,4);
         h5=plot((0:N-1)*Ts,uout);
         xlabel('t (s)');
         ylabel('uout');
         xlim([0 duration]);
      else
         clim=max(abs(uzz(:)));
         if clim>0
            caxis(gca1,[-clim clim]);
         end

         set(h2,'cdata',squeeze(uzz(Nif,:,:)));
         set(h3,'cdata',squeeze(uzz(:,Njf,:)));
         set(h4,'cdata',squeeze(uzz(:,:,Nkf)));
         set(h5,'ydata',uout);
         drawnow;
      end
   end
end
